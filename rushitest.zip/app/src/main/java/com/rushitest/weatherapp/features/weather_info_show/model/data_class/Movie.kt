package com.rushitest.weatherapp.features.weather_info_show.model.data_class

data class Movie(val name: String, val imageUrl: String, val category: String, val desc: String)